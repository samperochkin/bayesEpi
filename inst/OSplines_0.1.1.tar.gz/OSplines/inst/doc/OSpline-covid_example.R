## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>", fig.height=3, fig.width=5, margins=TRUE
)
knitr::knit_hooks$set(margins = function(before, options, envir) {
  if (!before) return()
  graphics::par(mar = c(1.5 + 0.9, 1.5 + 0.9, 0.2, 0.2), mgp = c(1.45, 0.45, 0), cex = 1.25, bty='n')
})

## ----setup--------------------------------------------------------------------
options(warn=-1)
library(OSplines)

## -----------------------------------------------------------------------------
head(covid_canada)

## ----warning=FALSE------------------------------------------------------------
fit_result <- model_fit(new_deaths ~ weekdays1 + weekdays2 + weekdays3 + weekdays4 + weekdays5 + weekdays6 +
                          f(smoothing_var = t, model = "IWP", order = 3, k = 100, sd.prior = list(prior = "exp", para = list(u = 0.02, alpha = 0.5))), 
                        data = covid_canada, method = "aghq", family = "Poisson")

## -----------------------------------------------------------------------------
summary(fit_result)

## ----warning=FALSE------------------------------------------------------------
plot(fit_result)

## ----warning=FALSE------------------------------------------------------------
predict_f <- predict(fit_result, variable = "t", newdata = data.frame(t = seq(from = 605, to = 615, by = 0.1)))
predict_f %>% ggplot(aes(x = x)) + geom_line(aes(y = mean), lty = "solid") +
  geom_line(aes(y = plower), lty = "dashed") +
  geom_line(aes(y = pupper), lty = "dashed") +
  theme_classic() + xlim(c(605,615)) + ylim(0,6)

## ----warning=FALSE------------------------------------------------------------
predict_f1st <- predict(fit_result, variable = "t", newdata = data.frame(t = seq(from = 605, to = 615, by = 0.1)), degree = 1)
predict_f1st %>% ggplot(aes(x = x)) + geom_line(aes(y = mean), lty = "solid") +
  geom_line(aes(y = plower), lty = "dashed") +
  geom_line(aes(y = pupper), lty = "dashed") +
  theme_classic() + xlim(c(605,615)) + ylim(c(-3,5))

## ----warning=FALSE------------------------------------------------------------
predict_f2nd <- predict(fit_result, variable = "t", newdata = data.frame(t = seq(from = 605, to = 617, by = 0.1)), degree = 2)
predict_f2nd %>% ggplot(aes(x = x)) + geom_line(aes(y = mean), lty = "solid") +
  geom_line(aes(y = plower), lty = "dashed") +
  geom_line(aes(y = pupper), lty = "dashed") +
  theme_classic()

## -----------------------------------------------------------------------------
if(requireNamespace("INLA", quietly=TRUE)) {

  inla_result <- INLA::inla(formula = new_deaths~-1 + weekdays1 + weekdays2 + weekdays3 + weekdays4 + weekdays5 + weekdays6 + f(t, model = "crw2", constr = F, hyper = list(prec = list(prior = "pc.prec", param = c(0.02, 0.5)))), data = covid_canada, family = "Poisson", control.compute=list(config = TRUE))
  
  inla_result$summary.random$t %>% filter(ID >= 0) %>% ggplot(aes(x = ID)) + geom_line(aes(y = mean), lty = "solid") +
  geom_line(aes(y = `0.025quant`), lty = "dashed") +
  geom_line(aes(y = `0.975quant`), lty = "dashed") +
  theme_classic() + xlim(c(605,615)) + ylim(0,6)
  
}


## -----------------------------------------------------------------------------
if(requireNamespace("INLA", quietly=TRUE)) {

  inla_result$summary.random$t %>% filter(ID <= 0) %>% mutate(ID = -ID) %>% 
  ggplot(aes(x = ID)) + geom_line(aes(y = mean), lty = "solid") +
  geom_line(aes(y = `0.025quant`), lty = "dashed") +
  geom_line(aes(y = `0.975quant`), lty = "dashed") +
  theme_classic() + xlim(c(605,615)) + ylim(c(-3,5))
  
}

